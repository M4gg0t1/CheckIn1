package com.twindev.mqtt_semana15;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // ELEMENTOS DE LA CONEXION
    private static final String BROKER = "tcp://broker.emqx.io:1883";
    private static final String CLIENT_ID = "mqtt_123123"; // Corrección aquí
    private static final String TOPIC_SUB = "lab/redes/android";
    private MqttHandler mqttHandler;

    // ELEMENTOS DE LA INTERFAZ
    private EditText mensaje;
    private TextView MostrarMensaje;
    private TextView MensajeRecibido;
    private Button BtnPublicar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        mensaje = findViewById(R.id.editTextMessage);
        MostrarMensaje = findViewById(R.id.textViewStatus);
        MensajeRecibido = findViewById(R.id.textViewReceived);
        BtnPublicar = findViewById(R.id.buttonPublish);

        mqttHandler = new MqttHandler();

        mqttHandler.setMessageListener(new MqttHandler.MessageListener() {
            @Override
            public void onMessageReceived(String topic, String message) {
                runOnUiThread(() -> MensajeRecibido.setText("Tópico: [" + topic + "] : " + message));
            }
        });
        mqttHandler.connect(BROKER,CLIENT_ID);
        mqttHandler.subscribe(TOPIC_SUB);
        BtnPublicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dato =mensaje.getText().toString();
                if(!dato.isEmpty()){
                    mqttHandler.publish(TOPIC_SUB,dato);
                    MostrarMensaje.setText("Mensjae publicado:"+ dato);
                }
            }
        });
    }
    @Override
    protected  void onDestroy(){
        mqttHandler.disconnect();
        super.onDestroy();
    }
}